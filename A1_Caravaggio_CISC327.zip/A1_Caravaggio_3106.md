FUNCTION #1: Add Book To Catalog

    Funtion Name: add_book_to_catalog

    implementation status (complete/partial): complete

    what is missing (if any):
    N/A

FUNCTION #2: Book Catalog Display

    Funtion Name: get_all_books

    implementation status (complete/partial): partial

    what is missing (if any): function decalration, parameters, expected return item and implementation of the function (the function body)

FUNCTION #3: Book Borrowing Interface

    Funtion Name: borrow_book_by_patron

    implementation status (complete/partial): complete

    what is missing (if any)
    N/A

FUNCTION #4: Book Return Processing

    Funtion Name: return_book_by_patron

    implementation status (complete/partial): partial

    what is missing (if any): implementation of the function (the function body)

FUNCTION #5: Late Fee Calculation API

    Funtion Name: calculate_late_fee_for_book

    implementation status (complete/partial): partial

    what is missing (if any): implementation of the function (the function body)

FUNCTION #6: Book Search Functionality

    Funtion Name:

    implementation status (complete/partial): partial

    what is missing (if any): implementation of the function (the function body)

FUNCTION #7: Patron Status Report

    Funtion Name:

    implementation status (complete/partial): partial

    what is missing (if any): implementation of the function (the function body)
